# ludum-dare-27 #

[![hurry](http://hughsk.github.io/ludum-dare-27/img/screenshots/0.png)](http://hughsk.github.io/ludum-dare-27)

hurry! is a small but speedy arcade shooter.

Dodge and shoot the red targets, grabbing the bombs as you go. Survive as long as possible and try to get a high score!

Mouse to shoot, WASD or arrow keys to move.

### [play](http://hughsk.github.io/ludum-dare-27) ###

### [votes appreciated :)](http://www.ludumdare.com/compo/ludum-dare-27/?action=preview&uid=21035) ###

**Untested in anything other then Chrome, so if you're having trouble getting it working try it there.**



