var bs = require('bindlestiff')

module.exports = bs.component()
  .needs('body')
  .on('init', function() {

  })
